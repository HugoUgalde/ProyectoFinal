/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.model;

import java.util.ArrayList;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.view.CursoPanel;

/**
 *
 * @author Hugo
 */
public class CursoList {

    private String[] cursoTemporal;
    private int select;
    private ArrayList<Curso> listaCursoTabla;

    public ArrayList<Curso> getListaCursoTabla() {
        return listaCursoTabla;
    }

    public void resetearArray() {
        listaCursoTabla = new ArrayList();
    }

    public void setListaCursoTabla(ArrayList<Curso> listaCursoTabla) {
        this.listaCursoTabla = listaCursoTabla;
    }

    public void add(Curso curso) {
        listaCursoTabla.add(curso);
    }

    public void remove(Curso curso) {
        listaCursoTabla.remove(curso);
    }

    public int getSelect() {
        return select;
    }

    public void setSelect(int select) {
        this.select = select;
    }

    public String[] getCursoTemporal() {
        return cursoTemporal;
    }

    public void setCursoTemporal(String[] cursoTemporal) {
        this.cursoTemporal = cursoTemporal;
    }

    public CursoList() {
        listaCursoTabla = new ArrayList();
    }

    public String[][] getMatrix(List<Curso> cursoList) {
        String[][] nuevoArreglo = new String[cursoList.size()][CursoPanel.HEADER_CURSO.length];
        for (int i = 0; i < nuevoArreglo.length; i++) {
            for (int j = 0; j < nuevoArreglo[0].length; j++) {
                nuevoArreglo[i][j] = cursoList.get(i).getData(j);
            }
        }
        return nuevoArreglo;
    }

    public Curso find(List<Curso> cursoList, int sigla) {
        for (Curso curso : cursoList) {
            if (curso.getSigla() == sigla) {
                return curso;
            }
        }
        return null;
    }
}
