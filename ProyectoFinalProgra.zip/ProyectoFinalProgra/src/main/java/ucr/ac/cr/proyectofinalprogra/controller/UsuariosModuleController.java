/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Perfil;
import ucr.ac.cr.proyectofinalprogra.logic.PerfilController;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.logic.UsuarioController;
import ucr.ac.cr.proyectofinalprogra.model.CarreraList;
import ucr.ac.cr.proyectofinalprogra.model.PlanEstudioList;
import ucr.ac.cr.proyectofinalprogra.model.UsuariosList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.MenuFrame;
import ucr.ac.cr.proyectofinalprogra.view.UsuarioAsociarPanel;
import ucr.ac.cr.proyectofinalprogra.view.UsuarioPanel;

/**
 *
 * @author Hugo
 */
public class UsuariosModuleController implements ActionListener {

    UsuarioPanel usuarioPanel;
    UsuarioAsociarPanel usuarioAsociarPanel;
    ControllerPersistence controllerPersistence;
    PerfilController perfilController;
    UsuarioController usuarioController;
    UsuariosList usuariosList;
    MenuFrame menuFrame;
    PlanEstudioList planEstudioList;
    CarreraList carreraList;

    public UsuariosModuleController(UsuarioPanel usuarioPanelParam, ControllerPersistence controllerPersistenceParam, UsuariosList usuariosListParam, MenuFrame menuFrameParam, PlanEstudioList planEstudioListParam, CarreraList carreraListParam, UsuarioAsociarPanel usuarioAsociarPanelParam) {
        usuarioPanel = usuarioPanelParam;
        controllerPersistence = controllerPersistenceParam;
        usuarioAsociarPanel = usuarioAsociarPanelParam;
        planEstudioList = planEstudioListParam;
        carreraList = carreraListParam;
        perfilController = new PerfilController(controllerPersistenceParam);
        usuarioController = new UsuarioController(controllerPersistenceParam);
        menuFrame = menuFrameParam;
        usuariosList = usuariosListParam;
        usuarioAsociarPanel.Listen(this);
        usuarioPanel.Listen(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Asociar":             
                    try {
                String perfilAsociado = usuarioPanel.cbxPerfil.getSelectedItem().toString();
                Perfil nuevoPerfil = new Perfil(perfilAsociado, perfilAsociado);
                List<Perfil> listPerfil = new ArrayList();
                listPerfil.add(nuevoPerfil);
                perfilController.crearPerfil(nuevoPerfil);

                //Plan de estudio y carrera en blanco;
                List<PlanEstudios> listPlanEstudios = new ArrayList();
                List<Carrera> listCarrera = new ArrayList();
                //***********

                Usuario usuarioAntiguo = usuariosList.getUsuarioTemp();

                Usuario usuarioModificado = new Usuario(usuarioAntiguo.getId(),
                        usuarioAntiguo.getApellido(),
                        usuarioAntiguo.getNombre(),
                        usuarioAntiguo.getTelefono(),
                        usuarioAntiguo.getContraseña(),
                        usuarioAntiguo.getNombreUsuario(),
                        usuarioAntiguo.getCorreo(),
                        usuarioAntiguo.getCarnet(),
                        listPerfil,
                        listPlanEstudios,
                        listCarrera);

                usuarioController.modificarUsuario(usuarioModificado);
                usuariosList.setUsuarioTemp(usuarioModificado);
                System.out.println("Perfil Asociado correatamente");

                List<PlanEstudios> listaPlanEstudioBuscar = controllerPersistence.buscarPlanEstudios();
                usuarioAsociarPanel.inicializarComboBoxPlanEstudios(listaPlanEstudioBuscar);
                menuFrame.tblPanel.setSelectedIndex(5);

            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;

            case "AsociarTodo":
                System.out.println("asociar todo ");
                try {
                    //plan estudios
                    List<PlanEstudios> listaPlanEstudioBuscar = controllerPersistence.buscarPlanEstudios();
                    if (!listaPlanEstudioBuscar.isEmpty()) {

                        PlanEstudios planEstudios = planEstudioList.findString(listaPlanEstudioBuscar, String.valueOf(usuarioAsociarPanel.cbxPlanEstudios.getSelectedItem()));
                        if (planEstudios != null) {
                            //carreras
                            List<Carrera> listaCarreraBuscar = new ArrayList();
                            listaCarreraBuscar = controllerPersistence.buscarCarreras();
                            Carrera carrera = carreraList.find(listaCarreraBuscar, String.valueOf(usuarioAsociarPanel.cbxPlanEstudios.getSelectedItem()));
                            //Colecciones para usuario
                            listaCarreraBuscar.add(carrera);
                            listaPlanEstudioBuscar.add(planEstudios);

                            Usuario usuarioAntiguo = usuariosList.getUsuarioTemp();

                            Usuario usuarioModificado = new Usuario(usuarioAntiguo.getId(),
                                    usuarioAntiguo.getApellido(),
                                    usuarioAntiguo.getNombre(),
                                    usuarioAntiguo.getTelefono(),
                                    usuarioAntiguo.getContraseña(),
                                    usuarioAntiguo.getNombreUsuario(),
                                    usuarioAntiguo.getCorreo(),
                                    usuarioAntiguo.getCarnet(),
                                    usuarioAntiguo.getPerfilCollection(),
                                    listaPlanEstudioBuscar,
                                    listaCarreraBuscar);

                            usuarioController.modificarUsuario(usuarioModificado);
                            usuariosList.setUsuarioTemp(usuarioModificado);
                            menuFrame.tblPanel.setSelectedIndex(0);
                            System.out.println("Plan de estudios y carrera asociados correatamente");
                        } else {
                            System.out.println("Ingrese un plan valido");
                        }
                    } else {
                        System.out.println("No existen planes de estudio");
                    }
                } catch (Exception ex) {
                    System.out.println("error: " + ex);
                }

                break;
        }

    }
}
