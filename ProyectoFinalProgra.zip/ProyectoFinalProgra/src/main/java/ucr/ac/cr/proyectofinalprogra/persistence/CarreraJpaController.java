/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.persistence;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.IllegalOrphanException;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.NonexistentEntityException;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.PreexistingEntityException;

/**
 *
 * @author Hugo
 */
public class CarreraJpaController implements Serializable {

    public CarreraJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public CarreraJpaController() {
        emf = Persistence.createEntityManagerFactory("persistenceUnit");
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Carrera carrera) throws PreexistingEntityException, Exception {
        if (carrera.getUsuarioCollection() == null) {
            carrera.setUsuarioCollection(new ArrayList<Usuario>());
        }
        if (carrera.getPlanEstudiosCollection() == null) {
            carrera.setPlanEstudiosCollection(new ArrayList<PlanEstudios>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Usuario> attachedUsuarioCollection = new ArrayList<Usuario>();
            for (Usuario usuarioCollectionUsuarioToAttach : carrera.getUsuarioCollection()) {
                usuarioCollectionUsuarioToAttach = em.getReference(usuarioCollectionUsuarioToAttach.getClass(), usuarioCollectionUsuarioToAttach.getId());
                attachedUsuarioCollection.add(usuarioCollectionUsuarioToAttach);
            }
            carrera.setUsuarioCollection(attachedUsuarioCollection);
            Collection<PlanEstudios> attachedPlanEstudiosCollection = new ArrayList<PlanEstudios>();
            for (PlanEstudios planEstudiosCollectionPlanEstudiosToAttach : carrera.getPlanEstudiosCollection()) {
                planEstudiosCollectionPlanEstudiosToAttach = em.getReference(planEstudiosCollectionPlanEstudiosToAttach.getClass(), planEstudiosCollectionPlanEstudiosToAttach.getId());
                attachedPlanEstudiosCollection.add(planEstudiosCollectionPlanEstudiosToAttach);
            }
            carrera.setPlanEstudiosCollection(attachedPlanEstudiosCollection);
            em.persist(carrera);
            for (Usuario usuarioCollectionUsuario : carrera.getUsuarioCollection()) {
                usuarioCollectionUsuario.getCarreraCollection().add(carrera);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
            }
            for (PlanEstudios planEstudiosCollectionPlanEstudios : carrera.getPlanEstudiosCollection()) {
                Carrera oldCarreraCodigoOfPlanEstudiosCollectionPlanEstudios = planEstudiosCollectionPlanEstudios.getCarreraCodigo();
                planEstudiosCollectionPlanEstudios.setCarreraCodigo(carrera);
                planEstudiosCollectionPlanEstudios = em.merge(planEstudiosCollectionPlanEstudios);
                if (oldCarreraCodigoOfPlanEstudiosCollectionPlanEstudios != null) {
                    oldCarreraCodigoOfPlanEstudiosCollectionPlanEstudios.getPlanEstudiosCollection().remove(planEstudiosCollectionPlanEstudios);
                    oldCarreraCodigoOfPlanEstudiosCollectionPlanEstudios = em.merge(oldCarreraCodigoOfPlanEstudiosCollectionPlanEstudios);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCarrera(carrera.getCodigo()) != null) {
                throw new PreexistingEntityException("Carrera " + carrera + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

   public void edit(Carrera carrera) throws IllegalOrphanException, NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
        em = getEntityManager();
        em.getTransaction().begin();
        Carrera persistentCarrera = em.find(Carrera.class, carrera.getCodigo());
        Collection<Usuario> usuarioCollectionOld = persistentCarrera.getUsuarioCollection();
        Collection<Usuario> usuarioCollectionNew = carrera.getUsuarioCollection();
        Collection<PlanEstudios> planEstudiosCollectionOld = persistentCarrera.getPlanEstudiosCollection();
        Collection<PlanEstudios> planEstudiosCollectionNew = carrera.getPlanEstudiosCollection();

        // Asegúrate de que usuarioCollectionNew no sea nulo
        if (usuarioCollectionNew == null) {
            usuarioCollectionNew = new ArrayList<>();
        }

        // Asegúrate de que planEstudiosCollectionNew no sea nulo
        if (planEstudiosCollectionNew == null) {
            planEstudiosCollectionNew = new ArrayList<>();
        }

        List<String> illegalOrphanMessages = null;
        for (PlanEstudios planEstudiosCollectionOldPlanEstudios : planEstudiosCollectionOld) {
            if (!planEstudiosCollectionNew.contains(planEstudiosCollectionOldPlanEstudios)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<>();
                }
                illegalOrphanMessages.add("Debes mantener PlanEstudios " + planEstudiosCollectionOldPlanEstudios + " ya que su campo carreraCodigo no es nulo.");
            }
        }
        if (illegalOrphanMessages != null) {
            throw new IllegalOrphanException(illegalOrphanMessages);
        }

        Collection<Usuario> attachedUsuarioCollectionNew = new ArrayList<>();
        for (Usuario usuarioCollectionNewUsuarioToAttach : usuarioCollectionNew) {
            usuarioCollectionNewUsuarioToAttach = em.getReference(usuarioCollectionNewUsuarioToAttach.getClass(), usuarioCollectionNewUsuarioToAttach.getId());
            attachedUsuarioCollectionNew.add(usuarioCollectionNewUsuarioToAttach);
        }
        usuarioCollectionNew = attachedUsuarioCollectionNew;
        carrera.setUsuarioCollection(usuarioCollectionNew);

        Collection<PlanEstudios> attachedPlanEstudiosCollectionNew = new ArrayList<>();
        for (PlanEstudios planEstudiosCollectionNewPlanEstudiosToAttach : planEstudiosCollectionNew) {
            planEstudiosCollectionNewPlanEstudiosToAttach = em.getReference(planEstudiosCollectionNewPlanEstudiosToAttach.getClass(), planEstudiosCollectionNewPlanEstudiosToAttach.getId());
            attachedPlanEstudiosCollectionNew.add(planEstudiosCollectionNewPlanEstudiosToAttach);
        }
        planEstudiosCollectionNew = attachedPlanEstudiosCollectionNew;
        carrera.setPlanEstudiosCollection(planEstudiosCollectionNew);
        carrera = em.merge(carrera);

        for (Usuario usuarioCollectionOldUsuario : usuarioCollectionOld) {
            if (!usuarioCollectionNew.contains(usuarioCollectionOldUsuario)) {
                usuarioCollectionOldUsuario.getCarreraCollection().remove(carrera);
                usuarioCollectionOldUsuario = em.merge(usuarioCollectionOldUsuario);
            }
        }
        for (Usuario usuarioCollectionNewUsuario : usuarioCollectionNew) {
            if (!usuarioCollectionOld.contains(usuarioCollectionNewUsuario)) {
                usuarioCollectionNewUsuario.getCarreraCollection().add(carrera);
                usuarioCollectionNewUsuario = em.merge(usuarioCollectionNewUsuario);
            }
        }
        for (PlanEstudios planEstudiosCollectionNewPlanEstudios : planEstudiosCollectionNew) {
            if (!planEstudiosCollectionOld.contains(planEstudiosCollectionNewPlanEstudios)) {
                Carrera oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios = planEstudiosCollectionNewPlanEstudios.getCarreraCodigo();
                planEstudiosCollectionNewPlanEstudios.setCarreraCodigo(carrera);
                planEstudiosCollectionNewPlanEstudios = em.merge(planEstudiosCollectionNewPlanEstudios);
                if (oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios != null && !oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios.equals(carrera)) {
                    oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios.getPlanEstudiosCollection().remove(planEstudiosCollectionNewPlanEstudios);
                    oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios = em.merge(oldCarreraCodigoOfPlanEstudiosCollectionNewPlanEstudios);
                }
            }
        }
        em.getTransaction().commit();
    } catch (Exception ex) {
        String msg = ex.getLocalizedMessage();
        if (msg == null || msg.length() == 0) {
            String id = carrera.getCodigo();
            if (findCarrera(id) == null) {
                throw new NonexistentEntityException("La carrera con id " + id + " ya no existe.");
            }
        }
        throw ex;
    } finally {
        if (em != null) {
            em.close();
        }
    }
}



    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Carrera carrera;
            try {
                carrera = em.getReference(Carrera.class, id);
                carrera.getCodigo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The carrera with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<PlanEstudios> planEstudiosCollectionOrphanCheck = carrera.getPlanEstudiosCollection();
            for (PlanEstudios planEstudiosCollectionOrphanCheckPlanEstudios : planEstudiosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Carrera (" + carrera + ") cannot be destroyed since the PlanEstudios " + planEstudiosCollectionOrphanCheckPlanEstudios + " in its planEstudiosCollection field has a non-nullable carreraCodigo field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Usuario> usuarioCollection = carrera.getUsuarioCollection();
            for (Usuario usuarioCollectionUsuario : usuarioCollection) {
                usuarioCollectionUsuario.getCarreraCollection().remove(carrera);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
            }
            em.remove(carrera);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Carrera> findCarreraEntities() {
        return findCarreraEntities(true, -1, -1);
    }

    public List<Carrera> findCarreraEntities(int maxResults, int firstResult) {
        return findCarreraEntities(false, maxResults, firstResult);
    }

    private List<Carrera> findCarreraEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Carrera.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Carrera findCarrera(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Carrera.class, id);
        } finally {
            em.close();
        }
    }

    public int getCarreraCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Carrera> rt = cq.from(Carrera.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
