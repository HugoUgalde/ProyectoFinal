/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.model.CarreraList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.CarreraPanel;
import ucr.ac.cr.proyectofinalprogra.view.FrameCarreraAgregar;
import ucr.ac.cr.proyectofinalprogra.view.FrameCarreraModificar;

/**
 *
 * @author Hugo
 */
public class CarreraModuleController implements ActionListener, MouseListener {

    CarreraPanel carreraPanel;
    FrameCarreraAgregar frameCarreraAgregar;
    FrameCarreraModificar frameCarreraModificar;
    ControllerPersistence controllerPersistence;
    CarreraList carreraList;

    public CarreraModuleController(CarreraPanel carreraPanelParam, ControllerPersistence controllerPersistenceParam, CarreraList carreraListParam) {
        carreraPanel = carreraPanelParam;
        controllerPersistence = controllerPersistenceParam;
        carreraList = carreraListParam;
        frameCarreraAgregar = new FrameCarreraAgregar();
        frameCarreraModificar = new FrameCarreraModificar();
        frameCarreraAgregar.Listen(this);
        frameCarreraModificar.Listen(this);
        carreraPanel.Listen(this);
        carreraPanel.ListenMouse(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Agregar":
                frameCarreraAgregar.setVisible(true);
                break;

            case "AgregarCarrera":
                if (frameCarreraAgregar.isVoid() == true) {
                    System.out.println("Complete todos los datos");
                } else {
                    try {
                        Carrera carrera = new Carrera(frameCarreraAgregar.txtCodigo.getText(),
                                frameCarreraAgregar.txtNombre.getText(),
                                frameCarreraAgregar.txtDescripcion.getText(),
                                frameCarreraAgregar.txtPerfilProfesional.getText(),
                                frameCarreraAgregar.txtMercadoLaboral.getText());

                        controllerPersistence.crearCarrera(carrera);

                        List<Carrera> listaCarrera = controllerPersistence.buscarCarreras();
                        carreraPanel.setTable(carreraPanel.HEADER_CARRERA, carreraList.getMatrix(listaCarrera));

                        frameCarreraAgregar.clean();
                        frameCarreraAgregar.setVisible(false);

                    } catch (Exception ex) {
                        System.out.println("Exepcion: " + ex);
                    }
                }
                break;

            case "Volver":
                frameCarreraAgregar.setVisible(false);
                frameCarreraModificar.setVisible(false);
                break;

            case "Modificar":
                try {
                if (carreraList.getSelect() != null) {
                    frameCarreraModificar.setVisible(true);
                    Carrera carrera = carreraList.find(controllerPersistence.buscarCarreras(), carreraList.getSelect());
                    frameCarreraModificar.txtCodigo.setText(carrera.getCodigo());
                    frameCarreraModificar.txtNombre.setText(carrera.getNombre());
                    frameCarreraModificar.txtDescripcion.setText(carrera.getDescripcion());
                    frameCarreraModificar.txtPerfilProfesional.setText(carrera.getPerfilProfesional());
                    frameCarreraModificar.txtMercadoLaboral.setText(String.valueOf(carrera.getMercadoLaboral()));
                    carreraList.setSelect(null);
                } else {
                    System.out.println("Seleccione una curso de la tabla ");
                }
            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;

            case "ModificarCarrera":
                try {
                Carrera carrera = new Carrera(frameCarreraModificar.txtCodigo.getText(),
                        frameCarreraModificar.txtNombre.getText(),
                        frameCarreraModificar.txtDescripcion.getText(),
                        frameCarreraModificar.txtPerfilProfesional.getText(),
                        frameCarreraModificar.txtMercadoLaboral.getText());

                controllerPersistence.modificarCarrera(carrera);
                carreraList.setSelect(null);

                List<Carrera> listaCarrera = controllerPersistence.buscarCarreras();
                carreraPanel.setTable(carreraPanel.HEADER_CARRERA, carreraList.getMatrix(listaCarrera));

                frameCarreraModificar.clean();
                frameCarreraModificar.setVisible(false);

                System.out.println("Curso modificado correctamente");

            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (carreraPanel.isVisible()) {
                String[] carrera;
                carrera = carreraPanel.getRow();
                carreraList.setCarreraTemporal(carrera);

                Carrera carreraFind = carreraList.find(controllerPersistence.buscarCarreras(), carrera[0]);
                carreraList.setSelect(carreraFind.getCodigo());
                System.out.println(carreraFind.getCodigo());
            }
        } catch (Exception ex) {
            System.out.println("error: " + ex);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
