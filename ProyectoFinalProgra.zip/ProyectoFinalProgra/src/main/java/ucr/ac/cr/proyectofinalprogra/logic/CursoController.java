/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.logic;

import java.util.List;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;

/**
 *
 * @author Hugo
 */
public class CursoController {
       ControllerPersistence controllerPersistence;

    public CursoController(ControllerPersistence controllerPersistenceParam) {
        controllerPersistence = new ControllerPersistence();
    }

    public void crearCurso(Curso curso) {
        controllerPersistence.crearCurso(curso);
    }

    public void modificarCurso(Curso curso) {
        controllerPersistence.modificarCurso(curso);
    }

    public List<Curso> buscarCursos() {
       return controllerPersistence.buscarCursos();
    }
}
