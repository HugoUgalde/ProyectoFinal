/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.logic;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Hugo
 */
@Entity
@Table(name = "plan_estudios")
@NamedQueries({
    @NamedQuery(name = "PlanEstudios.findAll", query = "SELECT p FROM PlanEstudios p"),
    @NamedQuery(name = "PlanEstudios.findById", query = "SELECT p FROM PlanEstudios p WHERE p.id = :id"),
    @NamedQuery(name = "PlanEstudios.findByDescripcion", query = "SELECT p FROM PlanEstudios p WHERE p.descripcion = :descripcion"),
    @NamedQuery(name = "PlanEstudios.findByCantidadCreditos", query = "SELECT p FROM PlanEstudios p WHERE p.cantidadCreditos = :cantidadCreditos"),
    @NamedQuery(name = "PlanEstudios.findByFechaAprobacion", query = "SELECT p FROM PlanEstudios p WHERE p.fechaAprobacion = :fechaAprobacion"),
    @NamedQuery(name = "PlanEstudios.findByFechaVigor", query = "SELECT p FROM PlanEstudios p WHERE p.fechaVigor = :fechaVigor")})
public class PlanEstudios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @Column(name = "cantidad_creditos")
    private int cantidadCreditos;
    @Basic(optional = false)
    @Column(name = "fecha_aprobacion")
    @Temporal(TemporalType.DATE)
    private Date fechaAprobacion;
    @Basic(optional = false)
    @Column(name = "fecha_vigor")
    @Temporal(TemporalType.DATE)
    private Date fechaVigor;
    @JoinTable(name = "plan_estudios_has_usuario", joinColumns = {
        @JoinColumn(name = "plan_estudios_id", referencedColumnName = "id")}, inverseJoinColumns = {
        @JoinColumn(name = "usuario_id", referencedColumnName = "id")})
    @ManyToMany
    private Collection<Usuario> usuarioCollection;
    @ManyToMany(mappedBy = "planEstudiosCollection")
    private Collection<Curso> cursoCollection;
    @JoinColumn(name = "carrera_codigo", referencedColumnName = "codigo")
    @ManyToOne(optional = false)
    private Carrera carreraCodigo;

    public PlanEstudios() {
    }

    public PlanEstudios(Integer id) {
        this.id = id;
    }

    public PlanEstudios(String descripcion, int cantidadCreditos, Date fechaAprobacion, Date fechaVigor, Carrera carreraCodigo) {
        this.descripcion = descripcion;
        this.cantidadCreditos = cantidadCreditos;
        this.fechaAprobacion = fechaAprobacion;
        this.fechaVigor = fechaVigor;
        this.carreraCodigo = carreraCodigo;
    }
    
    public PlanEstudios(int id, String descripcion, int cantidadCreditos, Date fechaAprobacion, Date fechaVigor, Carrera carreraCodigo,Collection<Curso> cursoCollection, Collection<Usuario> usuarioCollection) {
        this.id = id;
        this.descripcion = descripcion;
        this.cantidadCreditos = cantidadCreditos;
        this.fechaAprobacion = fechaAprobacion;
        this.fechaVigor = fechaVigor;
        this.carreraCodigo = carreraCodigo;
        this.cursoCollection = cursoCollection;
        this.usuarioCollection = usuarioCollection;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCantidadCreditos() {
        return cantidadCreditos;
    }

    public void setCantidadCreditos(int cantidadCreditos) {
        this.cantidadCreditos = cantidadCreditos;
    }

    public Date getFechaAprobacion() {
        return fechaAprobacion;
    }

    public void setFechaAprobacion(Date fechaAprobacion) {
        this.fechaAprobacion = fechaAprobacion;
    }

    public Date getFechaVigor() {
        return fechaVigor;
    }

    public void setFechaVigor(Date fechaVigor) {
        this.fechaVigor = fechaVigor;
    }

    public Collection<Usuario> getUsuarioCollection() {
        return usuarioCollection;
    }

    public void setUsuarioCollection(Collection<Usuario> usuarioCollection) {
        this.usuarioCollection = usuarioCollection;
    }

    public Collection<Curso> getCursoCollection() {
        return cursoCollection;
    }

    public void setCursoCollection(Collection<Curso> cursoCollection) {
        this.cursoCollection = cursoCollection;
    }

    public Carrera getCarreraCodigo() {
        return carreraCodigo;
    }

    public void setCarreraCodigo(Carrera carreraCodigo) {
        this.carreraCodigo = carreraCodigo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PlanEstudios)) {
            return false;
        }
        PlanEstudios other = (PlanEstudios) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ucr.ac.cr.proyectofinalprogra.model.PlanEstudios[ id=" + id + " ]";
    }

    public String getData(int colum) {
        switch (colum) {
            case 0 -> {
                return String.valueOf(this.getId());
            }
            case 1 -> {
                return this.getDescripcion();
            }
            case 2 -> {
                return String.valueOf(this.getCantidadCreditos());
            }
            case 3 -> {
                return String.valueOf(this.getFechaAprobacion());
            }
            case 4 -> {
                return String.valueOf(this.getFechaVigor());
            }
            case 5 -> {
                return String.valueOf(this.getCarreraCodigo().getCodigo());
            }
            
        }
        return "";
    }

}
