/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package ucr.ac.cr.proyectofinalprogra;

import ucr.ac.cr.proyectofinalprogra.controller.LoginController;

/**
 *
 * @author Hugo
 */
public class ProyectoFinalProgra {

    public static void main(String[] args) {
       new LoginController();
       }
}
