/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.model.CursoList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.CursoPanel;
import ucr.ac.cr.proyectofinalprogra.view.FrameCursoAgregar;
import ucr.ac.cr.proyectofinalprogra.view.FrameCursoModificar;

/**
 *
 * @author Hugo
 */
public class CursoModuleController implements ActionListener, MouseListener {
    
    CursoPanel cursoPanel;
    FrameCursoAgregar frameCursoAgregar;
    FrameCursoModificar frameCursoModificar;
    ControllerPersistence controllerPersistence;
    CursoList cursoList;
    
    public CursoModuleController(CursoPanel cursoPanelParam, ControllerPersistence controllerPersistenceParam, CursoList cursoListParam) {
        cursoPanel = cursoPanelParam;
        controllerPersistence = controllerPersistenceParam;
        cursoList = cursoListParam;
        frameCursoAgregar = new FrameCursoAgregar();
        frameCursoModificar = new FrameCursoModificar();
        frameCursoAgregar.Listen(this);
        frameCursoModificar.Listen(this);
        cursoPanel.Listen(this);
        cursoPanel.ListenMouse(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Agregar":
                frameCursoAgregar.setVisible(true);
                break;
            
            case "AgregarCurso":
                if (frameCursoAgregar.isVoid() == true) {
                    System.out.println("Complete todos los datos");
                } else {
                    try {
                        Curso curso = new Curso(Integer.valueOf(frameCursoAgregar.txtSigla.getText()),
                                frameCursoAgregar.txtBloque.getText(),
                                Integer.parseInt(frameCursoAgregar.txtHorasTrabajo.getText()),
                                Integer.parseInt(frameCursoAgregar.txtHorasLectivas.getText()),
                                Integer.parseInt(frameCursoAgregar.txtCantidadCreditos.getText()),
                                frameCursoAgregar.txtModalidad.getText(),
                                frameCursoAgregar.txtDescripcion.getText(),
                                frameCursoAgregar.txtNombre.getText());
                        
                        controllerPersistence.crearCurso(curso);
                        
                        List<Curso> listaCursos = controllerPersistence.buscarCursos();
                        cursoPanel.setTable(CursoPanel.HEADER_CURSO, cursoList.getMatrix(listaCursos));
                        
                        frameCursoAgregar.clean();
                        frameCursoAgregar.setVisible(false);
                        
                    } catch (Exception ex) {
                        System.out.println("Exepcion: " + ex);
                    }
                }
                break;
            
            case "Volver":
                frameCursoAgregar.setVisible(false);
                frameCursoModificar.setVisible(false);
                break;
            
            case "Modificar":
                try {
                if (cursoList.getSelect() != 0) {
                    frameCursoModificar.setVisible(true);
                    Curso curso = cursoList.find(controllerPersistence.buscarCursos(), cursoList.getSelect());
                    frameCursoModificar.txtBloque.setText(curso.getBloque());
                    frameCursoModificar.txtCantidadCreditos.setText(String.valueOf(curso.getCantidadCreditos()));
                    frameCursoModificar.txtDescripcion.setText(curso.getDescripcion());
                    frameCursoModificar.txtHorasLectivas.setText(String.valueOf(curso.getHorasLectivas()));
                    frameCursoModificar.txtHorasTrabajo.setText(String.valueOf(curso.getHorasTrabajo()));
                    frameCursoModificar.txtModalidad.setText(curso.getModalidad());
                    frameCursoModificar.txtNombre.setText(curso.getNombre());
                    frameCursoModificar.txtSigla.setText(String.valueOf(curso.getSigla()));
                    cursoList.setSelect(0);
                } else {
                    System.out.println("Seleccione una curso de la tabla ");
                }
            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;
            
            case "ModificarCurso":
                try {
                Curso curso = new Curso(Integer.valueOf(frameCursoModificar.txtSigla.getText()),
                        frameCursoModificar.txtBloque.getText(),
                        Integer.parseInt(frameCursoModificar.txtHorasTrabajo.getText()),
                        Integer.parseInt(frameCursoModificar.txtHorasLectivas.getText()),
                        Integer.parseInt(frameCursoModificar.txtCantidadCreditos.getText()),
                        frameCursoModificar.txtModalidad.getText(),
                        frameCursoModificar.txtDescripcion.getText(),
                        frameCursoModificar.txtNombre.getText());
                
                controllerPersistence.modificarCurso(curso);
                cursoList.setSelect(0);
                
                List<Curso> listaCursos = controllerPersistence.buscarCursos();
                cursoPanel.setTable(CursoPanel.HEADER_CURSO, cursoList.getMatrix(listaCursos));
                
                frameCursoModificar.clean();
                frameCursoModificar.setVisible(false);
                
                System.out.println("Curso modificado correctamente");
                
            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;
        }
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (cursoPanel.isVisible()) {
                String[] carrera;
                carrera = cursoPanel.getRow();
                cursoList.setCursoTemporal(carrera);
                
                Curso curso = cursoList.find(controllerPersistence.buscarCursos(), Integer.parseInt(carrera[0]));
                cursoList.setSelect(curso.getSigla());
                System.out.println(curso.getSigla());
            }
        } catch (Exception ex) {
            System.out.println("error: " + ex);
        }
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    
    @Override
    public void mouseExited(MouseEvent e) {
    }
    
}
