/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 *
 * @author Hugo
 */
public class DateModel {

    LocalDateTime now = LocalDateTime.now();

    public DateModel() {
    }    

    Date dateInicio = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());
    Date dateFin = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());

    public Date getDateInicio() {
        return dateInicio;
    }

    public Date getDateFin() {
        return dateFin;
    }
    
    

}
