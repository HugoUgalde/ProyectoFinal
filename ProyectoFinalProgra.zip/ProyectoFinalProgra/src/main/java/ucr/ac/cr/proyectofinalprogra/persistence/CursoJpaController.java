/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.persistence;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.NonexistentEntityException;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.PreexistingEntityException;

/**
 *
 * @author Hugo
 */
public class CursoJpaController implements Serializable {

    public CursoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public CursoJpaController() {
        emf = Persistence.createEntityManagerFactory("persistenceUnit");
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Curso curso) throws PreexistingEntityException, Exception {
        if (curso.getPlanEstudiosCollection() == null) {
            curso.setPlanEstudiosCollection(new ArrayList<PlanEstudios>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<PlanEstudios> attachedPlanEstudiosCollection = new ArrayList<PlanEstudios>();
            for (PlanEstudios planEstudiosCollectionPlanEstudiosToAttach : curso.getPlanEstudiosCollection()) {
                planEstudiosCollectionPlanEstudiosToAttach = em.getReference(planEstudiosCollectionPlanEstudiosToAttach.getClass(), planEstudiosCollectionPlanEstudiosToAttach.getId());
                attachedPlanEstudiosCollection.add(planEstudiosCollectionPlanEstudiosToAttach);
            }
            curso.setPlanEstudiosCollection(attachedPlanEstudiosCollection);
            em.persist(curso);
            for (PlanEstudios planEstudiosCollectionPlanEstudios : curso.getPlanEstudiosCollection()) {
                planEstudiosCollectionPlanEstudios.getCursoCollection().add(curso);
                planEstudiosCollectionPlanEstudios = em.merge(planEstudiosCollectionPlanEstudios);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCurso(curso.getSigla()) != null) {
                throw new PreexistingEntityException("Curso " + curso + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Curso curso) throws NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
        em = getEntityManager();
        em.getTransaction().begin();
        
        // Obtén la entidad Curso existente de la base de datos
        Curso persistentCurso = em.find(Curso.class, curso.getSigla());
        
        // Verifica si el curso existe
        if (persistentCurso == null) {
            throw new NonexistentEntityException("El curso con sigla " + curso.getSigla() + " no existe.");
        }
        
        Collection<PlanEstudios> planEstudiosCollectionOld = persistentCurso.getPlanEstudiosCollection();
        Collection<PlanEstudios> planEstudiosCollectionNew = curso.getPlanEstudiosCollection();

        // Inicializa planEstudiosCollectionNew si es null
        if (planEstudiosCollectionNew == null) {
            planEstudiosCollectionNew = new ArrayList<>();
        }

        Collection<PlanEstudios> attachedPlanEstudiosCollectionNew = new ArrayList<PlanEstudios>();
        for (PlanEstudios planEstudiosCollectionNewPlanEstudiosToAttach : planEstudiosCollectionNew) {
            planEstudiosCollectionNewPlanEstudiosToAttach = em.getReference(planEstudiosCollectionNewPlanEstudiosToAttach.getClass(), planEstudiosCollectionNewPlanEstudiosToAttach.getId());
            attachedPlanEstudiosCollectionNew.add(planEstudiosCollectionNewPlanEstudiosToAttach);
        }
        planEstudiosCollectionNew = attachedPlanEstudiosCollectionNew;
        curso.setPlanEstudiosCollection(planEstudiosCollectionNew);
        curso = em.merge(curso);
        for (PlanEstudios planEstudiosCollectionOldPlanEstudios : planEstudiosCollectionOld) {
            if (!planEstudiosCollectionNew.contains(planEstudiosCollectionOldPlanEstudios)) {
                planEstudiosCollectionOldPlanEstudios.getCursoCollection().remove(curso);
                planEstudiosCollectionOldPlanEstudios = em.merge(planEstudiosCollectionOldPlanEstudios);
            }
        }
        for (PlanEstudios planEstudiosCollectionNewPlanEstudios : planEstudiosCollectionNew) {
            if (!planEstudiosCollectionOld.contains(planEstudiosCollectionNewPlanEstudios)) {
                planEstudiosCollectionNewPlanEstudios.getCursoCollection().add(curso);
                planEstudiosCollectionNewPlanEstudios = em.merge(planEstudiosCollectionNewPlanEstudios);
            }
        }
        em.getTransaction().commit();
    } catch (Exception ex) {
        String msg = ex.getLocalizedMessage();
        if (msg == null || msg.length() == 0) {
            Integer id = curso.getSigla();
            if (findCurso(id) == null) {
                throw new NonexistentEntityException("El curso con sigla " + id + " no existe.");
            }
        }
        throw ex;
    } finally {
        if (em != null) {
            em.close();
        }
    }
}


    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Curso curso;
            try {
                curso = em.getReference(Curso.class, id);
                curso.getSigla();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The curso with id " + id + " no longer exists.", enfe);
            }
            Collection<PlanEstudios> planEstudiosCollection = curso.getPlanEstudiosCollection();
            for (PlanEstudios planEstudiosCollectionPlanEstudios : planEstudiosCollection) {
                planEstudiosCollectionPlanEstudios.getCursoCollection().remove(curso);
                planEstudiosCollectionPlanEstudios = em.merge(planEstudiosCollectionPlanEstudios);
            }
            em.remove(curso);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Curso> findCursoEntities() {
        return findCursoEntities(true, -1, -1);
    }

    public List<Curso> findCursoEntities(int maxResults, int firstResult) {
        return findCursoEntities(false, maxResults, firstResult);
    }

    private List<Curso> findCursoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Curso.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Curso findCurso(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Curso.class, id);
        } finally {
            em.close();
        }
    }

    public int getCursoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Curso> rt = cq.from(Curso.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
