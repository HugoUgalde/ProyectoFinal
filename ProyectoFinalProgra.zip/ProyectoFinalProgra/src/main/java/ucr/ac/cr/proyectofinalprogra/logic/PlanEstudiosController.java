/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.logic;

import java.util.List;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;

/**
 *
 * @author Hugo
 */
public class PlanEstudiosController {

    ControllerPersistence controllerPersistence;

    public PlanEstudiosController(ControllerPersistence controllerPersistenceParam) {
        controllerPersistence = new ControllerPersistence();
    }

    public void crearPlanEstudios(PlanEstudios planEstudios) {
        controllerPersistence.crearPlanEstudio(planEstudios);
    }

    public void modificarPlanEstudios(PlanEstudios planEstudios) {
        controllerPersistence.modificarPlanEstudio(planEstudios);
    }

    public void buscarPlanEstudios(PlanEstudios planEstudios) {
        controllerPersistence.buscarPlanEstudio(planEstudios);
    }

    public List<PlanEstudios> buscarPlanEstudios() {
        return controllerPersistence.buscarPlanEstudios();
    }

    public void eliminarPlanEstudios(PlanEstudios planEstudios) {
        controllerPersistence.eliminarPlanEstudio(planEstudios);
    }
}
