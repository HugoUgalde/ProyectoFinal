/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.model.CarreraList;
import ucr.ac.cr.proyectofinalprogra.model.DateModel;
import ucr.ac.cr.proyectofinalprogra.model.PlanEstudioList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.FramePlanEstudioAgregar;
import ucr.ac.cr.proyectofinalprogra.view.FramePlanEstudioModificar;
import ucr.ac.cr.proyectofinalprogra.view.PlanEstudiosPanel;

/**
 *
 * @author Hugo
 */
public class PlanEstudiosModuleController implements ActionListener, MouseListener {

    PlanEstudiosPanel planEstudiosPanel;
    FramePlanEstudioAgregar framePlanEstudioAgregar;
    FramePlanEstudioModificar framePlanEstudioModificar;
    ControllerPersistence controllerPersistence;
    PlanEstudioList planEstudioList;
    DateModel dateModel;
    CarreraList carreraList;

    public PlanEstudiosModuleController(PlanEstudiosPanel planEstudiosPanelParam, ControllerPersistence controllerPersistenceParam, PlanEstudioList planEstudioListParam) {
        planEstudiosPanel = planEstudiosPanelParam;
        controllerPersistence = controllerPersistenceParam;
        planEstudioList = planEstudioListParam;
        framePlanEstudioAgregar = new FramePlanEstudioAgregar();
        dateModel = new DateModel();
        carreraList = new CarreraList();
        framePlanEstudioModificar = new FramePlanEstudioModificar();
        framePlanEstudioAgregar.Listen(this);
        framePlanEstudioModificar.Listen(this);
        planEstudiosPanel.Listen(this);
        planEstudiosPanel.ListenMouse(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Agregar":
                framePlanEstudioAgregar.setVisible(true);
                List<Carrera> listaCarrera = controllerPersistence.buscarCarreras();
                framePlanEstudioAgregar.inicializarComboBox(listaCarrera);
                break;

            case "AgregarPlanEstudio":
                System.out.println("agregar");
                if (framePlanEstudioAgregar.isVoid() == true) {
                    System.out.println("Complete todos los datos");
                } else {
                    try {
                        List<Carrera> listaCarreraBuscar = controllerPersistence.buscarCarreras();
                        Carrera carrera = carreraList.find(listaCarreraBuscar, String.valueOf(framePlanEstudioAgregar.cbxCarrera.getSelectedItem()));
                        if (carrera != null) {
                            PlanEstudios planEstudios = new PlanEstudios(framePlanEstudioAgregar.txtDescripcion.getText(),
                                    Integer.parseInt(framePlanEstudioAgregar.txtCantidadCreditos.getText()),
                                    dateModel.getDateInicio(),
                                    dateModel.getDateFin(),
                                    carrera);

                            controllerPersistence.crearPlanEstudio(planEstudios);

                            List<PlanEstudios> listaPlanEstudio = controllerPersistence.buscarPlanEstudios();
                            planEstudiosPanel.setTable(PlanEstudiosPanel.HEADER_PLANESTUDIO, planEstudioList.getMatrix(listaPlanEstudio));

                            framePlanEstudioAgregar.clean();
                            framePlanEstudioAgregar.setVisible(false);
                        } else {
                            System.out.println("Carrera es null");
                        }
                    } catch (Exception ex) {
                        System.out.println("Exepcion: " + ex);
                    }
                }
                break;

            case "Volver":
                framePlanEstudioAgregar.setVisible(false);
                framePlanEstudioModificar.setVisible(false);
                break;

            case "Modificar":
                try {
                if (planEstudioList.getSelect() != 0) {
                    framePlanEstudioModificar.setVisible(true);
                    PlanEstudios planEstudios = planEstudioList.find(controllerPersistence.buscarPlanEstudios(), planEstudioList.getSelect());

                    framePlanEstudioModificar.txtId.setText(String.valueOf(planEstudios.getId()));
                    framePlanEstudioModificar.txtCantidadCreditos.setText(String.valueOf(planEstudios.getCantidadCreditos()));
                    framePlanEstudioModificar.txtDescripcion.setText(planEstudios.getDescripcion());
                    framePlanEstudioModificar.txtFechaAprovacion.setText(String.valueOf(planEstudios.getFechaAprobacion()));
                    framePlanEstudioModificar.txtFechaVigor.setText(String.valueOf(planEstudios.getFechaVigor()));

                    List<Carrera> listaCarreraBuscar = controllerPersistence.buscarCarreras();

                    framePlanEstudioModificar.inicializarComboBox(listaCarreraBuscar);

                    planEstudioList.setSelect(0);
                } else {
                    System.out.println("Seleccione una curso de la tabla ");
                }
            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;

//            case "ModificarCurso":
//                try {
//                Curso carrera = new Curso(Integer.valueOf(frameCursoModificar.txtSigla.getText()),
//                        frameCursoModificar.txtBloque.getText(),
//                        Integer.parseInt(frameCursoModificar.txtHorasTrabajo.getText()),
//                        Integer.parseInt(frameCursoModificar.txtHorasLectivas.getText()),
//                        Integer.parseInt(frameCursoModificar.txtCantidadCreditos.getText()),
//                        frameCursoModificar.txtModalidad.getText(),
//                        frameCursoModificar.txtDescripcion.getText(),
//                        frameCursoModificar.txtNombre.getText());
//
//                controllerPersistence.modificarCarrera(carrera);
//                planEstudioList.setSelect(0);
//
//                List<Curso> listaCursos = controllerPersistence.buscarCursos();
//                cursoPanel.setTable(CursoPanel.HEADER_CURSO, cursoList.getMatrix(listaCursos));
//
//                frameCursoModificar.clean();
//                frameCursoModificar.setVisible(false);
//
//                System.out.println("Curso modificado correctamente");
//
//            } catch (Exception ex) {
//                System.out.println("error: " + ex);
//            }
//            break;
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (planEstudiosPanel.isVisible()) {
                String[] carrera;
                carrera = planEstudiosPanel.getRow();
                planEstudioList.setPlanEstudioTemporal(carrera);

                PlanEstudios planEstudioFind = planEstudioList.find(controllerPersistence.buscarPlanEstudios(), Integer.parseInt(carrera[0]));
                planEstudioList.setSelect(planEstudioFind.getId());
                System.out.println(planEstudioFind.getId());
            }
        } catch (Exception ex) {
            System.out.println("error: " + ex);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
