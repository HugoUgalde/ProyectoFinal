/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.persistence;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.logic.Perfil;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.NonexistentEntityException;

/**
 *
 * @author Hugo
 */
public class ControllerPersistence {

    CarreraJpaController carreraJpaController = new CarreraJpaController();
    CursoJpaController cursoJpaController = new CursoJpaController();
    PerfilJpaController perfilJpaController = new PerfilJpaController();
    PlanEstudiosJpaController planEstudiosJpaController = new PlanEstudiosJpaController();
    UsuarioJpaController usuarioJpaController = new UsuarioJpaController();

    //Usuario
    public void crearUsuario(Usuario usuario) {
        try {
            usuarioJpaController.create(usuario);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modificarUsuario(Usuario usuario) {
        try {
            usuarioJpaController.edit(usuario);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Usuario buscarUsuario(Usuario usuario) {
       return usuarioJpaController.findUsuario(usuario.getId());
    }

    public List<Usuario> buscarUsuarios() {
        return usuarioJpaController.findUsuarioEntities();
    }

    public void eliminarUsuario(Usuario usuario) {
        try {
            usuarioJpaController.destroy(usuario.getId());
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //End usuario

    //Carrera
    public void crearCarrera(Carrera carrera) {
        try {
            carreraJpaController.create(carrera);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modificarCarrera(Carrera carrera) {
        try {
            carreraJpaController.edit(carrera);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<Carrera> buscarCarreras() {
        return carreraJpaController.findCarreraEntities();
    }
    //end carrera

    //Curso
    public void crearCurso(Curso curso) {
        try {
            cursoJpaController.create(curso);
            System.out.println("Agregado Corrrectamente");
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modificarCurso(Curso curso) {
        try {
            cursoJpaController.edit(curso);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<Curso> buscarCursos() {
        return cursoJpaController.findCursoEntities();
    }
    //end curso

    //Perfil
    public void crearPerfil(Perfil perfil) {
        try {
            perfilJpaController.create(perfil);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modificarPerfil(Perfil perfil) {
        try {
            perfilJpaController.edit(perfil);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void buscarPerfil(Perfil perfil) {
        perfilJpaController.findPerfil(perfil.getId());
    }

    public List<Perfil> buscarPerfiles() {
        return perfilJpaController.findPerfilEntities();
    }

    public void eliminarPerfil(Perfil perfil) {
        try {
            perfilJpaController.destroy(perfil.getId());
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //End perfil

    //Plan de estudio
    public void crearPlanEstudio(PlanEstudios planEstudio) {
        try {
            planEstudiosJpaController.create(planEstudio);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modificarPlanEstudio(PlanEstudios planEstudio) {
        try {
            planEstudiosJpaController.edit(planEstudio);
        } catch (Exception ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void buscarPlanEstudio(PlanEstudios planEstudio) {
        planEstudiosJpaController.findPlanEstudios(planEstudio.getId());
    }

    public List<PlanEstudios> buscarPlanEstudios() {
        return planEstudiosJpaController.findPlanEstudiosEntities();
    }

    public void eliminarPlanEstudio(PlanEstudios planEstudio) {
        try {
            planEstudiosJpaController.destroy(planEstudio.getId());
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControllerPersistence.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //End Plan de estudio

}
