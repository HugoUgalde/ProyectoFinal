/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.persistence;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.NonexistentEntityException;

/**
 *
 * @author Hugo
 */
public class PlanEstudiosJpaController implements Serializable {

    public PlanEstudiosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    public PlanEstudiosJpaController() {
        emf = Persistence.createEntityManagerFactory("persistenceUnit");
    }
    
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(PlanEstudios planEstudios) {
        if (planEstudios.getUsuarioCollection() == null) {
            planEstudios.setUsuarioCollection(new ArrayList<Usuario>());
        }
        if (planEstudios.getCursoCollection() == null) {
            planEstudios.setCursoCollection(new ArrayList<Curso>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Carrera carreraCodigo = planEstudios.getCarreraCodigo();
            if (carreraCodigo != null) {
                carreraCodigo = em.getReference(carreraCodigo.getClass(), carreraCodigo.getCodigo());
                planEstudios.setCarreraCodigo(carreraCodigo);
            }
            Collection<Usuario> attachedUsuarioCollection = new ArrayList<Usuario>();
            for (Usuario usuarioCollectionUsuarioToAttach : planEstudios.getUsuarioCollection()) {
                usuarioCollectionUsuarioToAttach = em.getReference(usuarioCollectionUsuarioToAttach.getClass(), usuarioCollectionUsuarioToAttach.getId());
                attachedUsuarioCollection.add(usuarioCollectionUsuarioToAttach);
            }
            planEstudios.setUsuarioCollection(attachedUsuarioCollection);
            Collection<Curso> attachedCursoCollection = new ArrayList<Curso>();
            for (Curso cursoCollectionCursoToAttach : planEstudios.getCursoCollection()) {
                cursoCollectionCursoToAttach = em.getReference(cursoCollectionCursoToAttach.getClass(), cursoCollectionCursoToAttach.getSigla());
                attachedCursoCollection.add(cursoCollectionCursoToAttach);
            }
            planEstudios.setCursoCollection(attachedCursoCollection);
            em.persist(planEstudios);
            if (carreraCodigo != null) {
                carreraCodigo.getPlanEstudiosCollection().add(planEstudios);
                carreraCodigo = em.merge(carreraCodigo);
            }
            for (Usuario usuarioCollectionUsuario : planEstudios.getUsuarioCollection()) {
                usuarioCollectionUsuario.getPlanEstudiosCollection().add(planEstudios);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
            }
            for (Curso cursoCollectionCurso : planEstudios.getCursoCollection()) {
                cursoCollectionCurso.getPlanEstudiosCollection().add(planEstudios);
                cursoCollectionCurso = em.merge(cursoCollectionCurso);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(PlanEstudios planEstudios) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            PlanEstudios persistentPlanEstudios = em.find(PlanEstudios.class, planEstudios.getId());
            Carrera carreraCodigoOld = persistentPlanEstudios.getCarreraCodigo();
            Carrera carreraCodigoNew = planEstudios.getCarreraCodigo();
            Collection<Usuario> usuarioCollectionOld = persistentPlanEstudios.getUsuarioCollection();
            Collection<Usuario> usuarioCollectionNew = planEstudios.getUsuarioCollection();
            Collection<Curso> cursoCollectionOld = persistentPlanEstudios.getCursoCollection();
            Collection<Curso> cursoCollectionNew = planEstudios.getCursoCollection();
            if (carreraCodigoNew != null) {
                carreraCodigoNew = em.getReference(carreraCodigoNew.getClass(), carreraCodigoNew.getCodigo());
                planEstudios.setCarreraCodigo(carreraCodigoNew);
            }
            Collection<Usuario> attachedUsuarioCollectionNew = new ArrayList<Usuario>();
            for (Usuario usuarioCollectionNewUsuarioToAttach : usuarioCollectionNew) {
                usuarioCollectionNewUsuarioToAttach = em.getReference(usuarioCollectionNewUsuarioToAttach.getClass(), usuarioCollectionNewUsuarioToAttach.getId());
                attachedUsuarioCollectionNew.add(usuarioCollectionNewUsuarioToAttach);
            }
            usuarioCollectionNew = attachedUsuarioCollectionNew;
            planEstudios.setUsuarioCollection(usuarioCollectionNew);
            Collection<Curso> attachedCursoCollectionNew = new ArrayList<Curso>();
            for (Curso cursoCollectionNewCursoToAttach : cursoCollectionNew) {
                cursoCollectionNewCursoToAttach = em.getReference(cursoCollectionNewCursoToAttach.getClass(), cursoCollectionNewCursoToAttach.getSigla());
                attachedCursoCollectionNew.add(cursoCollectionNewCursoToAttach);
            }
            cursoCollectionNew = attachedCursoCollectionNew;
            planEstudios.setCursoCollection(cursoCollectionNew);
            planEstudios = em.merge(planEstudios);
            if (carreraCodigoOld != null && !carreraCodigoOld.equals(carreraCodigoNew)) {
                carreraCodigoOld.getPlanEstudiosCollection().remove(planEstudios);
                carreraCodigoOld = em.merge(carreraCodigoOld);
            }
            if (carreraCodigoNew != null && !carreraCodigoNew.equals(carreraCodigoOld)) {
                carreraCodigoNew.getPlanEstudiosCollection().add(planEstudios);
                carreraCodigoNew = em.merge(carreraCodigoNew);
            }
            for (Usuario usuarioCollectionOldUsuario : usuarioCollectionOld) {
                if (!usuarioCollectionNew.contains(usuarioCollectionOldUsuario)) {
                    usuarioCollectionOldUsuario.getPlanEstudiosCollection().remove(planEstudios);
                    usuarioCollectionOldUsuario = em.merge(usuarioCollectionOldUsuario);
                }
            }
            for (Usuario usuarioCollectionNewUsuario : usuarioCollectionNew) {
                if (!usuarioCollectionOld.contains(usuarioCollectionNewUsuario)) {
                    usuarioCollectionNewUsuario.getPlanEstudiosCollection().add(planEstudios);
                    usuarioCollectionNewUsuario = em.merge(usuarioCollectionNewUsuario);
                }
            }
            for (Curso cursoCollectionOldCurso : cursoCollectionOld) {
                if (!cursoCollectionNew.contains(cursoCollectionOldCurso)) {
                    cursoCollectionOldCurso.getPlanEstudiosCollection().remove(planEstudios);
                    cursoCollectionOldCurso = em.merge(cursoCollectionOldCurso);
                }
            }
            for (Curso cursoCollectionNewCurso : cursoCollectionNew) {
                if (!cursoCollectionOld.contains(cursoCollectionNewCurso)) {
                    cursoCollectionNewCurso.getPlanEstudiosCollection().add(planEstudios);
                    cursoCollectionNewCurso = em.merge(cursoCollectionNewCurso);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = planEstudios.getId();
                if (findPlanEstudios(id) == null) {
                    throw new NonexistentEntityException("The planEstudios with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            PlanEstudios planEstudios;
            try {
                planEstudios = em.getReference(PlanEstudios.class, id);
                planEstudios.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The planEstudios with id " + id + " no longer exists.", enfe);
            }
            Carrera carreraCodigo = planEstudios.getCarreraCodigo();
            if (carreraCodigo != null) {
                carreraCodigo.getPlanEstudiosCollection().remove(planEstudios);
                carreraCodigo = em.merge(carreraCodigo);
            }
            Collection<Usuario> usuarioCollection = planEstudios.getUsuarioCollection();
            for (Usuario usuarioCollectionUsuario : usuarioCollection) {
                usuarioCollectionUsuario.getPlanEstudiosCollection().remove(planEstudios);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
            }
            Collection<Curso> cursoCollection = planEstudios.getCursoCollection();
            for (Curso cursoCollectionCurso : cursoCollection) {
                cursoCollectionCurso.getPlanEstudiosCollection().remove(planEstudios);
                cursoCollectionCurso = em.merge(cursoCollectionCurso);
            }
            em.remove(planEstudios);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<PlanEstudios> findPlanEstudiosEntities() {
        return findPlanEstudiosEntities(true, -1, -1);
    }

    public List<PlanEstudios> findPlanEstudiosEntities(int maxResults, int firstResult) {
        return findPlanEstudiosEntities(false, maxResults, firstResult);
    }

    private List<PlanEstudios> findPlanEstudiosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(PlanEstudios.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public PlanEstudios findPlanEstudios(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(PlanEstudios.class, id);
        } finally {
            em.close();
        }
    }

    public int getPlanEstudiosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<PlanEstudios> rt = cq.from(PlanEstudios.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
