/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.persistence;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ucr.ac.cr.proyectofinalprogra.logic.Perfil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.persistence.exceptions.NonexistentEntityException;

/**
 *
 * @author Hugo
 */
public class UsuarioJpaController implements Serializable {

    public UsuarioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public UsuarioJpaController() {
        emf = Persistence.createEntityManagerFactory("persistenceUnit");
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuario usuario) {
        if (usuario.getPerfilCollection() == null) {
            usuario.setPerfilCollection(new ArrayList<Perfil>());
        }
        if (usuario.getPlanEstudiosCollection() == null) {
            usuario.setPlanEstudiosCollection(new ArrayList<PlanEstudios>());
        }
        if (usuario.getCarreraCollection() == null) {
            usuario.setCarreraCollection(new ArrayList<Carrera>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Perfil> attachedPerfilCollection = new ArrayList<Perfil>();
            for (Perfil perfilCollectionPerfilToAttach : usuario.getPerfilCollection()) {
                perfilCollectionPerfilToAttach = em.getReference(perfilCollectionPerfilToAttach.getClass(), perfilCollectionPerfilToAttach.getId());
                attachedPerfilCollection.add(perfilCollectionPerfilToAttach);
            }
            usuario.setPerfilCollection(attachedPerfilCollection);
            Collection<PlanEstudios> attachedPlanEstudiosCollection = new ArrayList<PlanEstudios>();
            for (PlanEstudios planEstudiosCollectionPlanEstudiosToAttach : usuario.getPlanEstudiosCollection()) {
                planEstudiosCollectionPlanEstudiosToAttach = em.getReference(planEstudiosCollectionPlanEstudiosToAttach.getClass(), planEstudiosCollectionPlanEstudiosToAttach.getId());
                attachedPlanEstudiosCollection.add(planEstudiosCollectionPlanEstudiosToAttach);
            }
            usuario.setPlanEstudiosCollection(attachedPlanEstudiosCollection);
            Collection<Carrera> attachedCarreraCollection = new ArrayList<Carrera>();
            for (Carrera carreraCollectionCarreraToAttach : usuario.getCarreraCollection()) {
                carreraCollectionCarreraToAttach = em.getReference(carreraCollectionCarreraToAttach.getClass(), carreraCollectionCarreraToAttach.getCodigo());
                attachedCarreraCollection.add(carreraCollectionCarreraToAttach);
            }
            usuario.setCarreraCollection(attachedCarreraCollection);
            em.persist(usuario);
            for (Perfil perfilCollectionPerfil : usuario.getPerfilCollection()) {
                perfilCollectionPerfil.getUsuarioCollection().add(usuario);
                perfilCollectionPerfil = em.merge(perfilCollectionPerfil);
            }
            for (PlanEstudios planEstudiosCollectionPlanEstudios : usuario.getPlanEstudiosCollection()) {
                planEstudiosCollectionPlanEstudios.getUsuarioCollection().add(usuario);
                planEstudiosCollectionPlanEstudios = em.merge(planEstudiosCollectionPlanEstudios);
            }
            for (Carrera carreraCollectionCarrera : usuario.getCarreraCollection()) {
                carreraCollectionCarrera.getUsuarioCollection().add(usuario);
                carreraCollectionCarrera = em.merge(carreraCollectionCarrera);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuario usuario) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario persistentUsuario = em.find(Usuario.class, usuario.getId());
            Collection<Perfil> perfilCollectionOld = persistentUsuario.getPerfilCollection();
            Collection<Perfil> perfilCollectionNew = usuario.getPerfilCollection();
            Collection<PlanEstudios> planEstudiosCollectionOld = persistentUsuario.getPlanEstudiosCollection();
            Collection<PlanEstudios> planEstudiosCollectionNew = usuario.getPlanEstudiosCollection();
            Collection<Carrera> carreraCollectionOld = persistentUsuario.getCarreraCollection();
            Collection<Carrera> carreraCollectionNew = usuario.getCarreraCollection();
            Collection<Perfil> attachedPerfilCollectionNew = new ArrayList<Perfil>();
            for (Perfil perfilCollectionNewPerfilToAttach : perfilCollectionNew) {
                perfilCollectionNewPerfilToAttach = em.getReference(perfilCollectionNewPerfilToAttach.getClass(), perfilCollectionNewPerfilToAttach.getId());
                attachedPerfilCollectionNew.add(perfilCollectionNewPerfilToAttach);
            }
            perfilCollectionNew = attachedPerfilCollectionNew;
            usuario.setPerfilCollection(perfilCollectionNew);
            Collection<PlanEstudios> attachedPlanEstudiosCollectionNew = new ArrayList<PlanEstudios>();
            for (PlanEstudios planEstudiosCollectionNewPlanEstudiosToAttach : planEstudiosCollectionNew) {
                planEstudiosCollectionNewPlanEstudiosToAttach = em.getReference(planEstudiosCollectionNewPlanEstudiosToAttach.getClass(), planEstudiosCollectionNewPlanEstudiosToAttach.getId());
                attachedPlanEstudiosCollectionNew.add(planEstudiosCollectionNewPlanEstudiosToAttach);
            }
            planEstudiosCollectionNew = attachedPlanEstudiosCollectionNew;
            usuario.setPlanEstudiosCollection(planEstudiosCollectionNew);
            Collection<Carrera> attachedCarreraCollectionNew = new ArrayList<Carrera>();
            for (Carrera carreraCollectionNewCarreraToAttach : carreraCollectionNew) {
                carreraCollectionNewCarreraToAttach = em.getReference(carreraCollectionNewCarreraToAttach.getClass(), carreraCollectionNewCarreraToAttach.getCodigo());
                attachedCarreraCollectionNew.add(carreraCollectionNewCarreraToAttach);
            }
            carreraCollectionNew = attachedCarreraCollectionNew;
            usuario.setCarreraCollection(carreraCollectionNew);
            usuario = em.merge(usuario);
            for (Perfil perfilCollectionOldPerfil : perfilCollectionOld) {
                if (!perfilCollectionNew.contains(perfilCollectionOldPerfil)) {
                    perfilCollectionOldPerfil.getUsuarioCollection().remove(usuario);
                    perfilCollectionOldPerfil = em.merge(perfilCollectionOldPerfil);
                }
            }
            for (Perfil perfilCollectionNewPerfil : perfilCollectionNew) {
                if (!perfilCollectionOld.contains(perfilCollectionNewPerfil)) {
                    perfilCollectionNewPerfil.getUsuarioCollection().add(usuario);
                    perfilCollectionNewPerfil = em.merge(perfilCollectionNewPerfil);
                }
            }
            for (PlanEstudios planEstudiosCollectionOldPlanEstudios : planEstudiosCollectionOld) {
                if (!planEstudiosCollectionNew.contains(planEstudiosCollectionOldPlanEstudios)) {
                    planEstudiosCollectionOldPlanEstudios.getUsuarioCollection().remove(usuario);
                    planEstudiosCollectionOldPlanEstudios = em.merge(planEstudiosCollectionOldPlanEstudios);
                }
            }
            for (PlanEstudios planEstudiosCollectionNewPlanEstudios : planEstudiosCollectionNew) {
                if (!planEstudiosCollectionOld.contains(planEstudiosCollectionNewPlanEstudios)) {
                    planEstudiosCollectionNewPlanEstudios.getUsuarioCollection().add(usuario);
                    planEstudiosCollectionNewPlanEstudios = em.merge(planEstudiosCollectionNewPlanEstudios);
                }
            }
            for (Carrera carreraCollectionOldCarrera : carreraCollectionOld) {
                if (!carreraCollectionNew.contains(carreraCollectionOldCarrera)) {
                    carreraCollectionOldCarrera.getUsuarioCollection().remove(usuario);
                    carreraCollectionOldCarrera = em.merge(carreraCollectionOldCarrera);
                }
            }
            for (Carrera carreraCollectionNewCarrera : carreraCollectionNew) {
                if (!carreraCollectionOld.contains(carreraCollectionNewCarrera)) {
                    carreraCollectionNewCarrera.getUsuarioCollection().add(usuario);
                    carreraCollectionNewCarrera = em.merge(carreraCollectionNewCarrera);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuario.getId();
                if (findUsuario(id) == null) {
                    throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario usuario;
            try {
                usuario = em.getReference(Usuario.class, id);
                usuario.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.", enfe);
            }
            Collection<Perfil> perfilCollection = usuario.getPerfilCollection();
            for (Perfil perfilCollectionPerfil : perfilCollection) {
                perfilCollectionPerfil.getUsuarioCollection().remove(usuario);
                perfilCollectionPerfil = em.merge(perfilCollectionPerfil);
            }
            Collection<PlanEstudios> planEstudiosCollection = usuario.getPlanEstudiosCollection();
            for (PlanEstudios planEstudiosCollectionPlanEstudios : planEstudiosCollection) {
                planEstudiosCollectionPlanEstudios.getUsuarioCollection().remove(usuario);
                planEstudiosCollectionPlanEstudios = em.merge(planEstudiosCollectionPlanEstudios);
            }
            Collection<Carrera> carreraCollection = usuario.getCarreraCollection();
            for (Carrera carreraCollectionCarrera : carreraCollection) {
                carreraCollectionCarrera.getUsuarioCollection().remove(usuario);
                carreraCollectionCarrera = em.merge(carreraCollectionCarrera);
            }
            em.remove(usuario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuario> findUsuarioEntities() {
        return findUsuarioEntities(true, -1, -1);
    }

    public List<Usuario> findUsuarioEntities(int maxResults, int firstResult) {
        return findUsuarioEntities(false, maxResults, firstResult);
    }

    private List<Usuario> findUsuarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuario.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuario findUsuario(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuario> rt = cq.from(Usuario.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
