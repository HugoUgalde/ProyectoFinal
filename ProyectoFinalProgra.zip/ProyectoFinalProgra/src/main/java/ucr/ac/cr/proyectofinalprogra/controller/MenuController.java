/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.logic.Perfil;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.model.CarreraList;
import ucr.ac.cr.proyectofinalprogra.model.CursoList;
import ucr.ac.cr.proyectofinalprogra.model.PlanEstudioList;
import ucr.ac.cr.proyectofinalprogra.model.UsuariosList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.CarreraPanel;
import ucr.ac.cr.proyectofinalprogra.view.CursoPanel;
import ucr.ac.cr.proyectofinalprogra.view.MenuFrame;
import ucr.ac.cr.proyectofinalprogra.view.MenuPanel;
import ucr.ac.cr.proyectofinalprogra.view.PlanCursoPanel;
import ucr.ac.cr.proyectofinalprogra.view.PlanEstudiosPanel;
import ucr.ac.cr.proyectofinalprogra.view.ReportesPanel;
import ucr.ac.cr.proyectofinalprogra.view.UsuarioAsociarPanel;
import ucr.ac.cr.proyectofinalprogra.view.UsuarioPanel;

/**
 *
 * @author Hugo
 */
public class MenuController implements ActionListener {

    MenuFrame menuFrame;
    MenuPanel menuPanel;
    UsuarioPanel usuarioPanel;
    UsuarioAsociarPanel usuarioAsociarPanel;
    ControllerPersistence controllerPersistence;
    UsuariosModuleController usuariosModuleController;
    CursoModuleController cursoModuleController;
    PlanCursoModuleController planCursoModuleController;
    PlanCursoPanel planCursoPanel;
    CursoPanel cursoPanel;
    CarreraPanel carreraPanel;
    PlanEstudiosPanel planEstudiosPanel;
    ReportesPanel reportesPanel;
    PlanEstudiosModuleController planEstudiosModuleController;
    CarreraModuleController carreraModuleController;
    CursoList cursoList;
    CarreraList carreraList;
    PlanEstudioList planEstudioList;
    UsuariosList usuariosList;

    public MenuController(ControllerPersistence controllerPersistenceParam, UsuariosList usuariosListParam) {
        menuFrame = new MenuFrame();
        cursoPanel = menuFrame.getCursoPanel();
        controllerPersistence = controllerPersistenceParam;
        usuarioAsociarPanel = menuFrame.getUsuarioAsociarPanel();
        usuariosList = usuariosListParam;
        reportesPanel = menuFrame.getReportesPanel();
        menuPanel = menuFrame.getMenuPanel();
        planCursoPanel = menuFrame.getPlanCursoPanel();
        usuarioPanel = menuFrame.getUsuarioPanel();
        carreraPanel = menuFrame.getCarreraPanel();
        planEstudiosPanel = menuFrame.getPlanEstudiosPanel();
        cursoList = new CursoList();
        carreraList = new CarreraList();
        planEstudioList = new PlanEstudioList();
        menuFrame.Listen(this);
        menuFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {

            case "-":
                menuFrame.setExtendedState(1);
                break;

            case "X":
                System.exit(0);
                break;

            case "Usuarios":
                if (usuariosModuleController == null) {
                    usuariosModuleController = new UsuariosModuleController(usuarioPanel, controllerPersistence, usuariosList, menuFrame, planEstudioList, carreraList, usuarioAsociarPanel);
                }
                System.out.print(usuariosList.getUsuarioTemp().getPerfilCollection().isEmpty());

                if (usuariosList.getUsuarioTemp().getPerfilCollection().isEmpty()) {
                    System.out.print(usuariosList.getUsuarioTemp().getPerfilCollection().isEmpty());
                    menuFrame.tblPanel.setSelectedIndex(4);
                } else if (usuariosList.getUsuarioTemp().getPlanEstudiosCollection().isEmpty()) {
                    List<PlanEstudios> listaPlanEstudioBuscar = controllerPersistence.buscarPlanEstudios();
                    usuarioAsociarPanel.inicializarComboBoxPlanEstudios(listaPlanEstudioBuscar);
                    menuFrame.tblPanel.setSelectedIndex(5);
                } else {
                    menuFrame.tblPanel.setSelectedIndex(0);
                    System.out.println("Perfil ya asociado");
                }
                break;

            case "PlanEstudios":
                if (planEstudiosModuleController == null) {
                    planEstudiosModuleController = new PlanEstudiosModuleController(planEstudiosPanel, controllerPersistence, planEstudioList);
                }
                if (usuariosList.verificarPerfil()) {
                    List<PlanEstudios> listaPlanEstudio = controllerPersistence.buscarPlanEstudios();
                    planEstudiosPanel.setTable(PlanEstudiosPanel.HEADER_PLANESTUDIO, planEstudioList.getMatrix(listaPlanEstudio));
                    menuFrame.tblPanel.setSelectedIndex(3);
                } else {
                    menuFrame.tblPanel.setSelectedIndex(0);
                    System.out.println("Perfil sin suficientes permisos");
                }
                break;

            case "Carrera":
                if (carreraModuleController == null) {
                    carreraModuleController = new CarreraModuleController(carreraPanel, controllerPersistence, carreraList);
                }
                if (usuariosList.verificarPerfil()) {
                    List<Carrera> listaCarrera = controllerPersistence.buscarCarreras();
                    carreraPanel.setTable(CarreraPanel.HEADER_CARRERA, carreraList.getMatrix(listaCarrera));
                    menuFrame.tblPanel.setSelectedIndex(2);
                } else {
                    menuFrame.tblPanel.setSelectedIndex(0);
                    System.out.println("Perfil sin suficientes permisos");
                }
                break;

            case "Cursos":
                if (cursoModuleController == null) {
                    cursoModuleController = new CursoModuleController(cursoPanel, controllerPersistence, cursoList);
                }
                if (usuariosList.verificarPerfil()) {
                    List<Curso> listaCursos = controllerPersistence.buscarCursos();
                    cursoPanel.setTable(CursoPanel.HEADER_CURSO, cursoList.getMatrix(listaCursos));
                    menuFrame.tblPanel.setSelectedIndex(1);
                } else {
                    menuFrame.tblPanel.setSelectedIndex(0);
                    System.out.println("Perfil sin suficientes permisos");
                }
                break;

            case "Plan-Cursos":
                if (planCursoModuleController == null) {
                    planCursoModuleController = new PlanCursoModuleController(planCursoPanel, controllerPersistence, cursoList, planEstudioList);
                }
                if (usuariosList.verificarPerfil()) {
                    //ComboBox planEstudios
                    List<PlanEstudios> listaPlanEstudioBuscar = controllerPersistence.buscarPlanEstudios();
                    planCursoPanel.inicializarComboBoxPlanEstudios(listaPlanEstudioBuscar);
                    //tabla cursos
                    List<Curso> listaCursos = controllerPersistence.buscarCursos();
                    planCursoPanel.setTable(CursoPanel.HEADER_CURSO, cursoList.getMatrix(listaCursos));
                    cursoList.resetearArray();
                    menuFrame.tblPanel.setSelectedIndex(7);
                } else {
                    menuFrame.tblPanel.setSelectedIndex(0);
                    System.out.println("Perfil sin suficientes permisos");
                }
                break;

            case "Reportes":
                List<Usuario> listaUsuario = controllerPersistence.buscarUsuarios();
                List<Perfil> perfilList = controllerPersistence.buscarPerfiles();
                List<PlanEstudios> listaPlanEstudios = controllerPersistence.buscarPlanEstudios();
                List<Carrera> listaCarreras = controllerPersistence.buscarCarreras();

                reportesPanel.setTable(ReportesPanel.HEADER_REPORTES, usuariosList.getMatrix(listaUsuario, perfilList, listaPlanEstudios, listaCarreras));
                menuFrame.tblPanel.setSelectedIndex(6);
                break;

        }
    }

}
