/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.logic.UsuarioController;
import ucr.ac.cr.proyectofinalprogra.model.UsuariosList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.LoginFrame;
import ucr.ac.cr.proyectofinalprogra.view.LoginPanel;
import ucr.ac.cr.proyectofinalprogra.view.RegisterFrame;

/**
 *
 * @author Hugo
 */
public class LoginController implements ActionListener {

    LoginFrame loginFrame;
    LoginPanel loginPanel;
    UsuarioController usuarioController;
    ControllerPersistence controllerPersistence;
    UsuariosList usuariosList;
    RegisterFrame registerFrame;

    public LoginController() {
        loginFrame = new LoginFrame();
        registerFrame = new RegisterFrame();
        loginPanel = loginFrame.getLoginPanel();
        controllerPersistence = new ControllerPersistence();
        usuarioController = new UsuarioController(controllerPersistence);
        usuariosList = new UsuariosList();
        loginFrame.Listen(this);
        loginPanel.Listen(this);
        registerFrame.Listen(this);
        loginFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "X":
                System.exit(0);
                break;

            case "-":
                loginFrame.setExtendedState(1);
                break;

            case "Login":
                List<Usuario> userList = usuarioController.buscarUsuarios();
                Usuario userTemp = usuariosList.find(userList,
                        loginPanel.txtUser.getText(),
                        String.valueOf(loginPanel.txtPassword.getPassword()));
                if (userTemp != null) {
                    usuariosList.setUsuarioTemp(userTemp);
                    new MenuController(controllerPersistence, usuariosList);
                    System.out.println("Login satisfactorio");
                    loginPanel.clean();
                    loginFrame.setVisible(false);
                } else {
                    System.out.println("Credenciales erroneas");
                }
                break;

            case "RegisterFrame":
                registerFrame.setVisible(true);
                break;

            case "Volver":
                registerFrame.setVisible(false);
                break;

            case "Registarse":
                if (registerFrame.isVoid() == false) {
                    if (String.valueOf(String.valueOf(registerFrame.txtContraseña.getPassword())).equals(String.valueOf(registerFrame.txtConfirmarContraseña.getPassword()))) {
                        try {
                            usuarioController.crearUsuario(registerFrame.nuevoUsuario());
                            System.out.println("Usario registrado satisfactoriamente");
                            registerFrame.clean();
                            registerFrame.setVisible(false);
                        } catch (Exception ex) {
                            System.out.println("error: " + ex);
                        }
                    } else {
                        System.out.println("La contraseña no coincide");
                    }
                } else {
                    System.out.println("rellene todos los campos ");
                }
                break;
        }

    }

}
