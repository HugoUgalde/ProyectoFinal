/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.model;

import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Carrera;
import ucr.ac.cr.proyectofinalprogra.logic.Perfil;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.view.ReportesPanel;

/**
 *
 * @author Hugo
 */
public class UsuariosList {

    Usuario usuarioTemp;

    public UsuariosList() {
    }

    public Usuario getUsuarioTemp() {
        return usuarioTemp;
    }

    public void setUsuarioTemp(Usuario usuarioTemp) {
        this.usuarioTemp = usuarioTemp;
    }

    public Usuario find(List<Usuario> usuarioList, String userName, String password) {
        for (Usuario usuario : usuarioList) {
            if (usuario.getNombreUsuario().equals(userName)) {
                if (usuario.getContraseña().equals(password)) {
                    return usuario;
                }
            }
        }
        return null;
    }

    public Usuario findUsuario(List<Usuario> usuarioList, String user) {
        for (Usuario usuario : usuarioList) {
            if (usuario.getNombreUsuario().equals(user)) {
                return usuario;
            }
        }
        return null;
    }

    public String[][] getMatrix(List<Usuario> usuarioList, List<Perfil> perfilList, List<PlanEstudios> listaPlanEstudios, List<Carrera> listaCarreras) {
        String[][] nuevoArreglo = new String[listaCarreras.size()][ReportesPanel.HEADER_REPORTES.length];
        for (int i = 0; i < nuevoArreglo.length; i++) {
            for (int j = 0; j < nuevoArreglo[0].length; j++) {
                switch (j) {
                    case 0:
                        nuevoArreglo[i][j] = usuarioList.get(i).getNombreUsuario();
                        break;
                    case 1:
                        nuevoArreglo[i][j] = perfilList.get(i).getTipo();
                        break;
                    case 2:
                        nuevoArreglo[i][j] = String.valueOf(listaPlanEstudios.get(i).getId());
                        break;
                    case 3:
                        nuevoArreglo[i][j] = listaCarreras.get(i).getCodigo();
                        break;
                }
            }
        }
        return nuevoArreglo;
    }

    public boolean verificarPerfil() {
        List<Perfil> listuser = (List<Perfil>) usuarioTemp.getPerfilCollection();
        for (Perfil perfil : listuser) {
            if (perfil.getTipo().equals("Docente")) {
                System.out.println(perfil.getTipo());
                return true;
            }
        }
        return false;
    }

}
