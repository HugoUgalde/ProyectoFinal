/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.Curso;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.logic.Usuario;
import ucr.ac.cr.proyectofinalprogra.model.CarreraList;
import ucr.ac.cr.proyectofinalprogra.model.CursoList;
import ucr.ac.cr.proyectofinalprogra.model.PlanEstudioList;
import ucr.ac.cr.proyectofinalprogra.persistence.ControllerPersistence;
import ucr.ac.cr.proyectofinalprogra.view.CursoPanel;
import ucr.ac.cr.proyectofinalprogra.view.PlanCursoPanel;

/**
 *
 * @author Hugo
 */
public class PlanCursoModuleController implements ActionListener, MouseListener {

    PlanCursoPanel planCursoPanel;
    ControllerPersistence controllerPersistence;
    CursoList cursoList;
    PlanEstudioList planEstudioList;

    public PlanCursoModuleController(PlanCursoPanel planCursoPanelParam, ControllerPersistence controllerPersistenceParam, CursoList cursoListParam, PlanEstudioList planEstudioListParam) {
        planCursoPanel = planCursoPanelParam;
        controllerPersistence = controllerPersistenceParam;
        cursoList = cursoListParam;
        planEstudioList = planEstudioListParam;
        planCursoPanel.Listen(this);
        planCursoPanel.ListenMouse(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Agregar Curso":
                try {
                if (cursoList.getSelect() != 0) {
                    Curso curso = cursoList.find(controllerPersistence.buscarCursos(), cursoList.getSelect());
                    cursoList.add(curso);
                    cursoList.setSelect(0);

                    planCursoPanel.setTableSeleccionados(CursoPanel.HEADER_CURSO, cursoList.getMatrix(cursoList.getListaCursoTabla()));
                } else {
                    System.out.println("Seleccione los cursos a agregar");
                }
            } catch (Exception ex) {
                System.out.println("error: " + ex);
            }
            break;

            case "Confirmar":
                if (!cursoList.getListaCursoTabla().isEmpty()) {
                    List<PlanEstudios> planEstudioLista = controllerPersistence.buscarPlanEstudios();
                    PlanEstudios planEstudios = planEstudioList.findString(planEstudioLista, planCursoPanel.cbxPlanEstudios.getSelectedItem().toString());
                    List<Usuario> listUsuario = new ArrayList();
                    if (planEstudios != null) {
                        PlanEstudios newPlanEstudios = new PlanEstudios(planEstudios.getId(),
                                planEstudios.getDescripcion(),
                                planEstudios.getCantidadCreditos(),
                                planEstudios.getFechaAprobacion(),
                                planEstudios.getFechaVigor(),
                                planEstudios.getCarreraCodigo(),
                                cursoList.getListaCursoTabla(),
                                listUsuario);

                        controllerPersistence.modificarPlanEstudio(newPlanEstudios);

                        cursoList.resetearArray();
                        planCursoPanel.setTableSeleccionados(CursoPanel.HEADER_CURSO, cursoList.getMatrix(cursoList.getListaCursoTabla()));
                        System.out.println("Cursos asociados correctamente");
                    } else {
                        System.out.println("Seleccione un plan de estudios valido");
                    }
                } else {
                    System.out.println("Seleccione los cursos a agregar");
                }
                break;

        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (planCursoPanel.isVisible()) {
                String[] carrera;
                carrera = planCursoPanel.getRow();
                cursoList.setCursoTemporal(carrera);
                Curso curso = cursoList.find(controllerPersistence.buscarCursos(), Integer.parseInt(carrera[0]));
                cursoList.setSelect(curso.getSigla());
                System.out.println(curso.getSigla());
            }
        } catch (Exception ex) {
            System.out.println("error: " + ex);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
