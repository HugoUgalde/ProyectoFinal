/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyectofinalprogra.model;

import java.util.List;
import ucr.ac.cr.proyectofinalprogra.logic.PlanEstudios;
import ucr.ac.cr.proyectofinalprogra.view.PlanEstudiosPanel;

/**
 *
 * @author Hugo
 */
public class PlanEstudioList {

    private String[] planEstudioTemporal;
    private int select;

    public int getSelect() {
        return select;
    }

    public void setSelect(int select) {
        this.select = select;
    }

    public String[] getPlanEstudioTemporal() {
        return planEstudioTemporal;
    }

    public void setPlanEstudioTemporal(String[] cursoTemporal) {
        this.planEstudioTemporal = cursoTemporal;
    }

    public PlanEstudioList() {
    }

    public String[][] getMatrix(List<PlanEstudios> planEstudiosList) {
        String[][] nuevoArreglo = new String[planEstudiosList.size()][PlanEstudiosPanel.HEADER_PLANESTUDIO.length];
        for (int i = 0; i < nuevoArreglo.length; i++) {
            for (int j = 0; j < nuevoArreglo[0].length; j++) {
                nuevoArreglo[i][j] = planEstudiosList.get(i).getData(j);
            }
        }
        return nuevoArreglo;
    }

    public PlanEstudios find(List<PlanEstudios> planEstudiosList, int id) {
        for (PlanEstudios planEstudios : planEstudiosList) {
            if (planEstudios.getId() == id) {
                return planEstudios;
            }
        }
        return null;
    }

    public PlanEstudios findString(List<PlanEstudios> planEstudiosList, String codigo) {
        for (PlanEstudios planEstudios : planEstudiosList) {
            if (planEstudios.getCarreraCodigo().getCodigo().equals(codigo)) {
                return planEstudios;
            }
        }
        return null;
    }
}
